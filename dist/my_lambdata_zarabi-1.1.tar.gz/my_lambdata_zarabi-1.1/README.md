




# my_script.py:

      In this file, you can find Mean, Median, Mode function
      which you can use without using any library.

# Assignment_1.py :

     This file contains a function of 'split_dates_column'
     which can be used to extract new columns from the existing column in a dataframe ("MM/DD/YYYY", etc.)  

 # Assignment_2.py :

        'add_new_col' function tells you if you have a list and you want to add this into a dataframe, how can you change this into Series
        and then by using 'insert' make it a part of an already available dataframe.

                 